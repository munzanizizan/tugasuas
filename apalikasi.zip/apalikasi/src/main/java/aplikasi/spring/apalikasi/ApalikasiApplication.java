package aplikasi.spring.apalikasi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApalikasiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApalikasiApplication.class, args);
	}

}
