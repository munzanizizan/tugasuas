package aplikasi.spring.apalikasi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApalikasiApplicationTests {

	@Test
	void contextLoads() {
	}

}
